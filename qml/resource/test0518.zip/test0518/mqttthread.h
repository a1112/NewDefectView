#ifndef MQTTTHREAD_H
#define MQTTTHREAD_H


#include <QObject>
#include <QQuickItem>
#include <QSharedDataPointer>
#include <JQHttpServer>
#include <QtNetwork>
#include <QHostAddress>
#include "QJsonArray"
#include "QJsonObject"
#include <mqtt/qmqtt.h>
#include <QtCore/QDateTime>
//#include <QtMqtt/QMqttClient>
#include <QtWidgets/QMessageBox>
#include "QFileDialog"
#include <QCryptographicHash>
class mqttThreadData;

class mqttThread : public QObject
{
    Q_OBJECT
public:
    explicit mqttThread(QObject *parent = nullptr);
    mqttThread(const mqttThread &);
    mqttThread &operator=(const mqttThread &);
    ~mqttThread();
    void clientMqtt();
    void initializeHttpsServer();
    void initializeHttpServer();
    void Sleep(int msec);
    void querystatus();
    void upgradepara();
    void update1s();
    void mqtt_sub_false(QString topic);
    QString GetFileMD5(QString filePath);
    QStringList getFileListUnderDir(const QString &dirPath);
    uint updatetype = 0 ;
    QString topicstrEquipment ="#";//"EquipmentToOTA-00001";  #可以订阅到所有topic的消息
    QString topicstrServer = "ServerToOTA-";//00001
    QString IP = "192.168.124.1";
    quint16 mqttport = 1883;
    quint16 httpport = 23412;
    QMQTT::Message msg;
    QMQTT::Client *client;
    bool substate = false;//订阅state
    bool httplisten = false;

    struct data{
        //dev
           bool netstate = false;
        //json
           QString msgtype  ;
           quint16 seqNum = 0;
           quint16 seqNumget = 0;
           QString deviceId;
           QString deviceType;
           long timestamp;
           int softwarePackageType = 0;
           QString protocolVersion;
           QString softwareVersion;
           QString hardwareVersion;
           QString updateVersion;
           QString downloadUrl;
           QString OTAUserId;
           QString OTApassword;
           QString OTAtransprotocal;
           QString downloadMd5;
           QString description = "失败";
           int updateTime = 0;
           int code;//软件包状态码0 差分包（整包） 1：V2X可执行文件包 2：更新v2x文件包 3：更新config文件包
           int receiveResults;//结果码 0：成功 1：失败
           int progress;//设备升级进度
           bool ack;


           //程序变量
           QTime hearttime;
           bool heartstate= false;
           QString downloadIP;
           QString updatefilename="";
    };
    data updatedata;
signals:
    void tosetlogtext(QString text);
    void tosettabledata(QString id,QString type,QString sver,QString state);
    void tosendDialvalue(uint value);
public slots:
   void timeinit();
   void opensoursebutton1();//test
   void opensoursebutton2();//test
   void onHttpAccepted(const QPointer< JQHttpServer::Session > &session);
   void onMQTT_Received( QMQTT::Message message);
   void mqtt_connect_success(); //连接成功
   void mqtt_disconnect(); //连接断开
   void mqtt_sub_success(QString topic,quint8 qos) ;//订阅成功
   void mqtt_recv_msg(QMQTT::Message msg); //接收消息处理
   //void mqtt_publish_success(QMQTT::Message msg,quint8 qos);
   void gethttpfile();
   void oncomboxindex(int index);
   void getfileinfo(QString msg,QString filename,QString vision);
   void exit();
private:
    QSharedDataPointer<mqttThreadData> data;
};

#endif // MQTTTHREAD_H
