import QtQuick 2.12
import QtQml.Models 2.12
import QtQuick.Window 2.2
import QtQuick.Controls 2.2 as Controls
import QtQuick.Controls 2.2
import QtQuick.Controls 2.0
import QtQuick.Dialogs 1.2
import QtQuick.Layouts 1.3
import Qt.labs.platform 1.0
import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4
import QtQuick.XmlListModel 2.0
import QtQuick.Controls.Universal 2.2
import QtQuick.Controls 1.4
Rectangle {
    id: rectangle

    width: 660
    height: 660
    color: "#545454"








    Image {
        id: image2
        x: 211
        y: 136
        width: 237
        height: 218
        source: "content/11.png"
    }

    Label {
        id: label
        x: 170
        y: 20
        width: 319
        height: 40
        text: qsTr("OTA升级工具")
        font.bold: false
        font.pointSize: 17
        verticalAlignment: Text.AlignVCenter
        horizontalAlignment: Text.AlignHCenter
    }

    TableView {
        id: tableView
        x: 8
        y: 551
        width: 644
        height: 92
        section.property: "123"
        transformOrigin: Item.Right
        horizontalScrollBarPolicy: 1
        sortIndicatorOrder: 1
        sortIndicatorColumn: 1
        sortIndicatorVisible: false
        currentRow: 2


    }

    Text {
        id: element
        x: 20
        y: 420
        width: 87
        height: 31
        text: qsTr("升级文件")
        font.pixelSize: 20
    }
    Button {
        id: button
        x: 574
        y: 475
        width: 52
        height: 49
        text: qsTr("Button")
    }

    Button {
        id: button1
        x: 574
        y: 411
        width: 52
        height: 49
        text: qsTr("Button")
    }

    Text {
        id: element1
        x: 129
        y: 360
        width: 641
        height: 38
        text: qsTr("请先选择升级文件...")
        horizontalAlignment: Text.AlignHCenter
        transformOrigin: Item.Center
        anchors.horizontalCenterOffset: -9
        anchors.horizontalCenter: parent.horizontalCenter
        font.pixelSize: 12
    }

    Text {
        id: element2
        x: 120
        y: 423
        width: 441
        height: 28
        text: qsTr("diff_update_RSU_V0.1.2_20220507151726.tar.bz2")
        font.family: "Arial"
        font.pixelSize: 19
    }

    ComboBox {
        id: comboBox
        x: 392
        y: 475
        width: 110
        height: 49
        activeFocusOnPress: false
         property int maxHeight: 1000
         property alias currentIndex: listView.currentIndex
         property alias currentIndex2: delegatelistview.currentIndex
         property alias buttonTextSize: comboBoxButton.textSize
         property alias text: comboBoxButton.text
         property bool readOnly: false
         property variant listModel
         property int beforeDropIndex:0
         property int beforeDropIndex2: 0
         property color textColor: "white"
         property color borderColor: "olivedrab"
         property color backgroundColor: "#FF00688A"
         property color focus_borderColor: "lightsalmon"
        property color focus_backgroundColor: "#FF00688A"
        property color focus_textColor: "darkred"
    }

    Text {
        id: element3
        x: 20
        y: 482
        width: 140
        height: 35
        text: qsTr("选择升级类型:")
        font.pixelSize: 20
    }


    

}
