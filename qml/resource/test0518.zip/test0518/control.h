#ifndef CONTROL_H
#define CONTROL_H

#include <QObject>
#include <QWidget>
#include "QDate"
class control : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(QString name READ getName WRITE setName NOTIFY signalname)
    Q_PROPERTY(quint64 age READ getAge WRITE setAge NOTIFY signalage)
    Q_PROPERTY(QDate date READ getDate WRITE setDate NOTIFY signaldate)
public:
    explicit control(QWidget *parent = nullptr);

signals:

public slots:
    void opensoursebutton1();//test
    void opensoursebutton2();//test
    void testfunction(uint state);
    void oncomboxindex(int index);

public:

    void setName(QString name)noexcept;
    QString getName() const noexcept;
    void setAge(quint32 age) noexcept;
    quint32 getAge() const noexcept;
    void setDate(QDate date)noexcept;
    QDate getDate() const noexcept;
    void Sleep(int msec);
    void uimessage();
signals:
    void signalname();
    void signalage();
    void signaldate();
    void qmlCall();
    void tosettextEdit1(QString msg,QString filename,QString vision);
    void tosettextEdit2(QString msg);
    void tosendDialvalue(uint value);
private:
    QString m_name;
    quint32 m_age;
    QDate m_date;

};

#endif // CONTROL_H
