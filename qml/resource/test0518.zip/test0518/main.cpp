#include <QGuiApplication>
#include <QApplication>
#include <QQmlApplicationEngine>
#include "mqttthread.h"
#include "QFileDialog"
#include "control.h"
#include "QQuickView"
#include <QQmlProperty>
#include <QQuickItem>
#include <QMetaObject>
#include <QQmlContext>
#include <QQmlFileSelector>

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);



    mqttThread *mqtt = new mqttThread();
    mqtt->startTimer(1);
    control *ctrl = new control();
    QObject::connect(ctrl,SIGNAL(tosettextEdit1(QString,QString,QString)), mqtt, SLOT(getfileinfo(QString,QString,QString)));

//    QQuickView view;
////    view.connect(view.engine(), &QQmlEngine::quit, &app, &QCoreApplication::quit);
//    new QQmlFileSelector(view.engine(), &view);
//    view.setSource(QUrl("qrc:/dialcontrol.qml"));
//    view.setFlags(Qt::FramelessWindowHint);
////    view.show();



    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));//

    auto context = engine.rootContext();
    context->setContextProperty("ctrl",ctrl);
    auto context1 = engine.rootContext();
    context1->setContextProperty("mqtt",mqtt);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
        &app, [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        }, Qt::QueuedConnection);

   //Qt::FramelessWindowHint

    engine.load(url);
    if (engine.rootObjects().isEmpty())
        return -1;


//    auto root1 = engine.rootObjects();
//    auto pushButton1 = root1.first()->findChild<QObject*>("opensoursebutton1");
//    QObject::connect(pushButton1,SIGNAL(clicked()), ctrl, SLOT(opensoursebutton1()));

//    auto root2 = engine.rootObjects();
//    auto pushButton2 = root2.first()->findChild<QObject*>("opensoursebutton2");
//    QObject::connect(pushButton2,SIGNAL(clicked()), ctrl, SLOT(opensoursebutton2()));

//    auto root3 = engine.rootObjects();
//    auto pushButton3 = root3.first()->findChild<QObject*>("opensoursebutton2");
//    QObject::connect(pushButton3,SIGNAL(clicked()), ctrl, SLOT(oncomboxindex(int)));
    //ctrl->testfunction();

    return app.exec();
}


