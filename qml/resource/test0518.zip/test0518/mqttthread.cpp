﻿#include "mqttthread.h"
#include "qdebug.h"
#include <QQmlApplicationEngine>
#include <QGuiApplication>
#include "QFileDialog"
#include <QtCore>
#include <QImage>
#include <string>
#include "QTimer"
#include <QWidget>
#include "QApplication"
#include <windows.h>//winApi函数
#include <winbase.h>//winApi函数
#include <QCoreApplication>
#include "qstring.h"

QString filepath = "";
class mqttThreadData : public QSharedData
{
public:

};
//http://192.168.124.23:23412/diff_update_RSU_V0.1.2_20220507151726.tar.bz2

mqttThread::mqttThread(QObject *parent) : QObject(parent), data(new mqttThreadData)
{


    //initializeHttpsServer();

    QTimer *mTime = new QTimer();
    connect(mTime,&QTimer::timeout,this,[=]()
    {
        update1s();	//定时处理内容
    });
    mTime->start(5000);
    updatedata.hearttime = QTime::currentTime();
   QTimer::singleShot(1000,this, SLOT(timeinit()));
}

void mqttThread::update1s()
{
    //查询设备基本数据
    if(substate&& updatedata.heartstate)
        querystatus();
    //检测设备离线状态
    int time = updatedata.hearttime.secsTo(QTime::currentTime());
    if(time>30)
    {
         emit tosettabledata(updatedata.deviceId,updatedata.deviceType,updatedata.softwareVersion,"离线");
         updatedata.heartstate = false;
    }

    //qDebug()<<"time"<<time<<updatedata.hearttime;
}
void mqttThread::exit()
{

//    qDebug()<<"mqttThread::exit!";
//    qint64 pid = QCoreApplication::applicationPid();//获取当前进程的PID

//    QString cmd = QString("tskill -9 %1").arg(pid);//Linux 系统下，强制杀死当前进程命令

//    system(cmd.toLocal8Bit().data());
    qint64 pid = QCoreApplication::applicationPid();//获取当前进程的PID
    /**
     * 强制杀死当前进程，同时推出所有子线程
     * TASKKILL 参数解释：
     * /T : 杀死当前进程启动和其启动的所有子线程
     * /F: 强制杀死进程
     * */
    QString cmd = QString("TASKKILL /PID %1 /F").arg(pid);//Windows 系统下，杀死当前进程命令，不杀死其开启的子进程
    //    QString cmd = QString("TASKKILL /PID %1 /T /F").arg(pid);//Windows 系统下，杀死当前进程树，包括其开启的子进程

    //@ 可以，无dos黑窗口
    WinExec(cmd.toLocal8Bit().data(), SW_HIDE);//SW_HIDE：控制运行cmd时，不弹出cmd运行窗口

}
void mqttThread::timeinit()
{
    //测试
   //for(int i = 0 ; i < 60 ; i++){emit tosendDialvalue(i);Sleep(300);}


    qputenv( "QT_SSL_USE_TEMPORARY_KEYCHAIN", "1" );
    qSetMessagePattern( "%{time hh:mm:ss.zzz}: %{message}" );
    initializeHttpServer();
    clientMqtt();
}
mqttThread::mqttThread(const mqttThread &rhs) : data(rhs.data)
{

}

mqttThread &mqttThread::operator=(const mqttThread &rhs)
{
    if (this != &rhs)
        data.operator=(rhs.data);
    return *this;
}

mqttThread::~mqttThread()
{

}

void mqttThread::opensoursebutton1()
{
    qDebug()<<__FUNCTION__<<":opensoursebutton1 ok!";

}
void mqttThread::oncomboxindex(int index)
{
    qDebug() << "mqttThread oncomboxindex=" << index;
    updatedata.softwarePackageType = index;
    updatetype = index;
}
void mqttThread::opensoursebutton2()
{
    qDebug()<<__FUNCTION__<<":opensoursebutton2 -> 重新连接网络";
    if(!substate)
       clientMqtt();
    else
        emit tosetlogtext("\nMQTT已订阅成功!");
    if(!httplisten)
    {
        qputenv( "QT_SSL_USE_TEMPORARY_KEYCHAIN", "1" );
        qSetMessagePattern( "%{time hh:mm:ss.zzz}: %{message}" );
        initializeHttpServer();
    }
    else
        emit tosetlogtext("\nHTTP已成功侦听");
    if(updatedata.heartstate == false)
      {
       emit tosetlogtext("\n设备未上线!!");
     }
    Sleep(100);
}
void mqttThread::clientMqtt()
    {
    QString message = "test";

    client = new QMQTT::Client(); // 初始化QMQTT客户指针

    QObject::connect(client, SIGNAL(received(QMQTT::Message)),this, SLOT(onMQTT_Received(QMQTT::Message)));
    connect(client, SIGNAL(connected()), this, SLOT(mqtt_connect_success()));
    connect(client, SIGNAL(disconnected()), this, SLOT(mqtt_disconnect()));
    connect(client, SIGNAL(subscribed(QString,quint8)), this, SLOT(mqtt_sub_success(QString,quint8)));//
////  oneNet server ///
    QHostAddress host(IP); // 代理服务器 IP
    client->setKeepAlive(120); // 心跳
    client->setHost(host); // 设置 EMQ 代理服务器
    client->setPort(mqttport); // 设置 EMQ 代理服务器端口
    client->cleanSession();
    client->setVersion(QMQTT::MQTTVersion::V3_1_1); // 设置mqtt版本
    client->connectToHost(); // 连接 EMQ 代理服务器
    Sleep(500);
    substate = false;
    client->subscribe(topicstrEquipment,1);
    qDebug()<<"subscribe:"<<topicstrEquipment;

    Sleep(2000);
    if(!substate)
        mqtt_sub_false(topicstrEquipment);
    else
     querystatus();
}
void mqttThread::mqtt_connect_success() //连接成功
{
    qDebug()<<__FUNCTION__<<"连接成功";
    QString logtext;
    logtext = "\nMQTT{IP:"+IP+"port:"+mqttport+"连接成功}";
    emit tosetlogtext(logtext);
}

void mqttThread::mqtt_disconnect() //连接断开
{
    qDebug()<<__FUNCTION__<<"连接断开";
    substate=false;
}

void mqttThread::mqtt_sub_success(QString topic,quint8 qos) //订阅成功
{
    substate = true;
   qDebug()<<__FUNCTION__<<topic<<qos<<"订阅成功";
   QString logtext;
   logtext = "\nMQTT{ topic:"+topicstrEquipment+"订阅成功}";
   emit tosetlogtext(logtext);
}
void mqttThread::mqtt_sub_false(QString topic)
{
    qDebug()<<__FUNCTION__<<topic<<"订阅失败";
    QString logtext;
    logtext = "\nMQTT{ topic:"+topic+"订阅失败}";
    emit tosetlogtext(logtext);
}
void mqttThread::mqtt_recv_msg(QMQTT::Message msg) //接收消息处理
{
    QString recv_msg = "Topic:";
    QString data = msg.payload();
    recv_msg += msg.topic();
    recv_msg += "    Payload:";
    recv_msg += data;

    qDebug()<<__FUNCTION__<<recv_msg;
}


void mqttThread::querystatus()
{
    QJsonObject json;
    QString tempmsg ;
    json.insert("msgtype", QString("query-status"));//

    tempmsg = QString(QJsonDocument(json).toJson(QJsonDocument::Compact));
    msg.setTopic(topicstrServer+updatedata.deviceId);
    msg.setPayload(tempmsg.toLocal8Bit());
    client->publish(msg);
    qDebug()<<"publish:"<<json<<"str"<<tempmsg.toLocal8Bit();
}


void mqttThread::upgradepara()
{
    QJsonObject json;
    QString tempmsg ;
    QString localHostName = QHostInfo::localHostName();
    qDebug() << "计算机名：" << localHostName;
    //获取 IP 地址
    QHostInfo info = QHostInfo::fromName(localHostName);
    foreach(QHostAddress address,info.addresses())
    {
        if(address.protocol() == QAbstractSocket::IPv4Protocol)
        {

            if(address.toString().contains("192.168.124") == true)
            {
                qDebug() << "ipV4 地址：" << address.toString();
                updatedata.downloadIP = address.toString();
            }
        }
    }
    if(updatedata.downloadIP == "")
        qDebug() << "ipV4 地址无效（不包含192.168.124）";
    else
    {
        updatedata.downloadUrl = "http://"+updatedata.downloadIP+":23412/"+updatedata.updatefilename ;
        qDebug() << "downloadUrl:"<<updatedata.downloadUrl;
    }

    updatedata.seqNum++;
    updatedata.msgtype = "upgrade-para";
    json.insert("msgtype", QString(updatedata.msgtype));
    json.insert("seqNum", QString(QString::number(updatedata.seqNum)));
    json.insert("deviceId", QString(updatedata.deviceId));
    json.insert("deviceType", QString(updatedata.deviceType));
    json.insert("timestamp", QString(QString::number(updatedata.timestamp)));
    json.insert("softwarePackageType",(updatedata.softwarePackageType));
    json.insert("protocolVersion", QString(updatedata.protocolVersion));
    json.insert("softwareVersion", QString(updatedata.softwareVersion));
    json.insert("hardwareVersion", QString(updatedata.hardwareVersion));
    json.insert("updateVersion", QString(updatedata.updateVersion));
    json.insert("downloadUrl", QString(updatedata.downloadUrl));
    json.insert("downloadMd5", QString(updatedata.downloadMd5));
    json.insert("updateTime", QString(QString::number(updatedata.updateTime)));
    tempmsg = QString(QJsonDocument(json).toJson(QJsonDocument::Compact));
    msg.setTopic(topicstrServer+updatedata.deviceId);
    msg.setPayload(tempmsg.toLocal8Bit());
    client->publish(msg);
    emit tosetlogtext("\n升级下发数据:"+tempmsg);
    emit tosetlogtext("\n即将发送文件到设备，请稍后...");

    qDebug()<<"publish:"<<json<<"str"<<tempmsg.toLocal8Bit();

    for(int i = 0 ; i < 60 ; i++){emit tosendDialvalue(i);Sleep(300);}
}


void mqttThread::onMQTT_Received( QMQTT::Message message)
{
    QString str = message.payload();   
    QJsonDocument doc = QJsonDocument::fromJson(str.toUtf8());
    QJsonObject obj = doc.object();


    updatedata.msgtype = obj["msgtype"].toString();
    if(updatedata.msgtype == "upgrade-para" || updatedata.msgtype == "query-status")
        return;
    qDebug() <<"rcive: " << message.topic() <<"msgtype:"<<updatedata.msgtype<<"sourcedata:" <<str;

    //订阅topic "#"时，发布的数据也会被接收到，做一个简单的过滤

    if(updatedata.msgtype == "heartbeat")//心跳包，仅包含设备ID
    {
      if(obj["deviceId"].toString()!="")
      {
          updatedata.deviceId = obj["deviceId"].toString();
          updatedata.hearttime = QTime::currentTime();
          updatedata.heartstate = true;
          //qDebug()<<"heartbeat\n+deviceId:"<<updatedata.deviceId;
      }
       qDebug()<<"heartbeat\n+deviceId:"<<updatedata.deviceId;

    }
    else if(updatedata.msgtype == "response-query")//终端接收到服务器查询终端状态消息后，进行应答
    {
        updatedata.seqNumget = obj["seqNum"].toInt();//获取流水号
        updatedata.deviceId = obj["deviceId"].toString();
        if(obj["deviceType"].toString()!="")
          updatedata.deviceType = obj["deviceType"].toString();
        updatedata.timestamp = obj["timestamp"].toInt();
        if(obj["protocolVersion"].toString()!="")
          updatedata.protocolVersion = obj["protocolVersion"].toString();
        if(obj["softwareVersion"].toString()!="")
          updatedata.softwareVersion = obj["softwareVersion"].toString();
        updatedata.hardwareVersion = obj["hardwareVersion"].toString();
        qDebug()<<"response-query\n"<<"deviceId:"<<updatedata.deviceId<<"deviceType"<<updatedata.deviceType;
        qDebug()<<"timestamp"<<updatedata.timestamp<<"protocolVersion"<<updatedata.protocolVersion;
        qDebug()<<"softwareVersion"<<updatedata.softwareVersion<<"hardwareVersion"<<updatedata.hardwareVersion;
        emit tosetlogtext("deviceId:"+updatedata.deviceId+"deviceType"+updatedata.deviceType+"timestamp"+updatedata.timestamp);
        emit tosetlogtext("softwareVersion:"+updatedata.softwareVersion+"hardwareVersion"+updatedata.hardwareVersion);
    }
    else if(updatedata.msgtype == "response-para")//终端接收到服务器下发的升级信息参数消息后，进行应答
    {
        updatedata.seqNumget = obj["seqNum"].toInt();//获取流水号
        updatedata.deviceId = obj["deviceId"].toString();
        updatedata.deviceType = obj["deviceType"].toString();
        updatedata.timestamp = obj["timestamp"].toInt();
        updatedata.receiveResults = obj["receiveResults"].toInt();
        qDebug()<<"response-para\n"<<"deviceId:"<<updatedata.deviceId<<"deviceType"<<updatedata.deviceType<<"timestamp"<<updatedata.timestamp;
        qDebug()<<"receiveResults"<<updatedata.receiveResults;
        emit tosetlogtext("deviceId:"+updatedata.deviceId+"deviceType"+updatedata.deviceType+"timestamp"+updatedata.timestamp);
        emit tosetlogtext("receiveResults:"+updatedata.receiveResults);

    }
    else if(updatedata.msgtype == "download-status")//终端启动下载软件包操作时，根据软件包的下载情况以及校验上报该消息
    {
        updatedata.seqNumget = obj["seqNum"].toInt();//获取流水号
        updatedata.deviceId = obj["deviceId"].toString();
        updatedata.deviceType = obj["deviceType"].toString();
        updatedata.timestamp = obj["timestamp"].toInt();
        updatedata.code = obj["code"].toInt();
        qDebug()<<"download-status\n"<<"deviceId:"<<updatedata.deviceId<<"deviceType"<<updatedata.deviceType<<"timestamp"<<updatedata.timestamp;
        qDebug()<<"code"<<updatedata.code;
        emit tosetlogtext("deviceId:"+updatedata.deviceId+"deviceType"+updatedata.deviceType+"timestamp"+updatedata.timestamp);
        emit tosetlogtext("code:"+updatedata.code);
    }
    else if(updatedata.msgtype == "upgrade-status")//升级操作结束后，终端主动上报本次升级状态信息
    {

        updatedata.deviceId = obj["deviceId"].toString();

        updatedata.deviceType = obj["deviceType"].toString();
        updatedata.timestamp = obj["timestamp"].toInt();
        updatedata.code = obj["code"].toInt();
        updatedata.progress = obj["progress"].toInt();
        updatedata.softwareVersion = obj["softwareVersion"].toString();
        updatedata.hardwareVersion = obj["hardwareVersion"].toString();
        updatedata.description = obj["description"].toString();
        qDebug()<<"upgrade-status\n"<<"deviceId:"<<updatedata.deviceId<<"deviceType"<<updatedata.deviceType<<"timestamp"<<updatedata.timestamp;
        qDebug()<<"code"<<updatedata.code<<"progress"<<updatedata.progress;
        qDebug()<<"softwareVersion"<<updatedata.softwareVersion<<"hardwareVersion"<<updatedata.hardwareVersion;
        qDebug()<<"description"<<updatedata.description;

        emit tosetlogtext("deviceId:"+updatedata.deviceId+"deviceType"+updatedata.deviceType+"timestamp"+updatedata.timestamp);
        emit tosetlogtext("code:"+updatedata.code);
        emit tosetlogtext("progress:"+QString::number(updatedata.progress)+"softwareVersion"+updatedata.softwareVersion+"hardwareVersion"+updatedata.hardwareVersion);
        //emit tosetlogtext("description:"+updatedata.description);
        if(updatedata.description.contains("成功"))
        {
            for(int i = 60 ; i < 101 ; i++){emit tosendDialvalue(i);Sleep(100);}
            emit tosetlogtext("\n升级成功!!");
        }
        else
        {
            emit tosendDialvalue(0);
            emit tosetlogtext("\n升级失败:失败码:"+updatedata.description);
        }


    }
    if(updatedata.softwareVersion.length() > 10)
        updatedata.softwareVersion = updatedata.softwareVersion.split("-").at(0);
    QString st = "";
    switch (updatedata.deviceType.toInt()) {
    case 1:st="OBU";break; case 2:st="RSU";break;case 3:st="MEC";break;
        case 4:st="摄像头";break;case 5:st="毫米波雷达";break;case 6: st="激光雷达";break;  case 7:st="超声波雷达";break; }
    if(st!="")
      updatedata.deviceType = st;
    emit tosettabledata(updatedata.deviceId,updatedata.deviceType,updatedata.softwareVersion,"上线"+updatedata.hearttime.toString());
}


QStringList mqttThread::getFileListUnderDir(const QString &dirPath)
{
    QStringList fileList;
    QDir dir(dirPath);
    QFileInfoList fileInfoList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot | QDir::Dirs);
    foreach (auto fileInfo, fileInfoList) {
//        if(fileInfo.isDir())
//        {

//            getFileListUnderDir(fileInfo.absoluteFilePath());
//        }

        if(fileInfo.isFile())
        {
            qDebug() << __FUNCTION__ << "  : " << fileInfo.absoluteFilePath();
            fileList.append(fileInfo.fileName());
        }

    }
    return fileList;
}


void mqttThread::initializeHttpServer()
{
     QPointer< JQHttpServer::Session > session;

    static JQHttpServer::TcpServerManage tcpServerManage( 2 ); // 设置最大处理线程数，默认2个
    tcpServerManage.setHttpAcceptedCallback( []( const QPointer< JQHttpServer::Session > &session )
    { session->replyFile(filepath);} );

    //tcpServerManage.setHttpAcceptedCallback( std::bind( &mqttThread::onHttpAccepted,this,session,1) );

    httplisten = tcpServerManage.listen( QHostAddress::Any, httpport );

    if(httplisten == true)
    {
        QString logtext;
        logtext = "\nHTTP{ port:"+QString::number(httpport)+"打开成功}";//
        emit tosetlogtext(logtext);
    }
    else
    {
        QString logtext;
        logtext = "\nHTTP{ port:"+QString::number(httpport)+"打开失败}";// 失败
        emit tosetlogtext(logtext);
    }
    qDebug() << "HTTP server listen:ip port:" << httpport<<httplisten;

}

void mqttThread::initializeHttpsServer()
{
#ifndef QT_NO_SSL
    static JQHttpServer::SslServerManage sslServerManage( 2 ); // 设置最大处理线程数，默认2个

       sslServerManage.setHttpAcceptedCallback( []( const QPointer< JQHttpServer::Session > &session )
       {
           session->replyText(QString("Whatever you ask, I'll only respond to sb"));
           QString str = session->requestBody();
           //mqttThread::onHttpAccepted(str);
       } );

    const auto listenSucceed = sslServerManage.listen( QHostAddress::Any, 23413, ":/server.crt", ":/server.key" );
    qDebug() << "HTTPS server listen:" << listenSucceed;

    // 这是我在一个实际项目中用的配置（用认证的证书，访问时带绿色小锁），其中涉及到隐私的细节已经被替换，但是任然能够看出整体用法
    /*
    qDebug() << "listen:" << sslServerManage.listen(
                    QHostAddress::Any,
                    24684,
                    "xxx/__xxx_com.crt",
                    "xxx/__xxx_com.key",
                    {
                        { "xxx/__xxx_com.ca-bundle", QSsl::Pem },
                        { "xxx/COMODO RSA Certification Authority.crt", QSsl::Pem },
                        { "xxx/COMODO RSA Domain Validation Secure Server CA.cer", QSsl::Der }
                    }
                );
    */
#else
    qDebug() << "SSL not support"
#endif
}



void mqttThread::Sleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void mqttThread::gethttpfile()
{

       qDebug() << __FUNCTION__ <<"http send...";
       emit tosendDialvalue(0);
        if((!substate)||(!httplisten))
        {
          if(!substate)
            emit tosetlogtext("\nMQTT订阅失败!");
          if(!httplisten)
            emit tosetlogtext("\nHTTP服务器打开失败!");
           emit tosetlogtext("\n请点击仪表盘'刷新图标'重新连接或检查网络!!");
                return;
        }
          if(updatedata.heartstate == false)
            {
             emit tosetlogtext("\n设备未上线，请点击仪表盘'刷新图标'重新连接或检查网络!!");
             return;
           }
         if(filepath =="")
         {
          emit tosetlogtext("\n请选择升级文件!");
          return;
        }

       Sleep(500);
       upgradepara();

}

void mqttThread::getfileinfo(QString msg,QString filename,QString vision)
{
    QString md5 = "";
    md5 = GetFileMD5(msg);
    emit tosetlogtext("\nmd5:"+md5);
    updatedata.downloadMd5 = md5;
    updatedata.updatefilename = filename;
    updatedata.softwareVersion = vision;
    filepath = msg;
    qDebug() << __FUNCTION__ <<msg<<"md5"<<md5;
}

QString mqttThread::GetFileMD5(QString filePath)
{
    QFile file(filePath);
    QString md5 = "";
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray array = QCryptographicHash::hash(file.readAll(), QCryptographicHash::Md5).toHex();
        file.close();
        md5.append(array);
    }
    return md5;
}












void mqttThread::onHttpAccepted(const QPointer< JQHttpServer::Session > &session)
{
    // 回调发生在专用的处理线程内，不是主线程，也不是socket的生存线程，请注意线程安全
    // 若阻塞了此回调，那么新的连接将被阻塞（默认情况下有2个线程可以阻塞2次，第3个连接将被阻塞）

    //session->replyText( QString( "url:%1\nbody:%2" ).arg( session->requestUrl(), QString( session->requestBody() ) ) );
//    session->replyText("回调发生在专用的处理线程内，不是主线程，也不是socket的生存线程，请注意线程安全");

//    QByteArray text = {"https://192.168.0.103:23413/?userName=hfs.rar"};
//    QByteArray urlEncode = text.toPercentEncoding();
//    qDebug("编码后");
//    qDebug(urlEncode.constData());
//    QNetworkRequest request;
//    request.setHeader(QNetworkRequest::UserAgentHeader, "my-app/0.0.1");

    //session->replyRedirects( QUrl( "https://192.168.0.103:23413/?userName=hfs.rar"));//http://root@localhost:8080/appname/path?name=admin
    //console.log("https://hanyu.baidu.com/?name=" + encodeURIComponent("六十六"));
    //session->replyJsonObject( { { { "Content-Length:1232", "ok" } } } );
//    session->replyJsonArray( { "a", "b", "c" } );
    //session->replyText( QString( "url:%1\nbody:%2" ).arg( session->requestUrl(), QString( session->requestBody() ) ) );
    QMap< QString, QString > temp;
    temp = session->requestHeader();

    QString tempurlpath = session->requestUrlPath();
    qDebug() << "HTTP tempurlpath:"<<tempurlpath ;


    QString tempbody = session->requestBody();

    if(tempbody == "filename")
    {
        if(tempurlpath.contains("A"))
        {
         QStringList tempfile = getFileListUnderDir("/home/david/qtproject/filetest/test/download/A");

         foreach (QString filename, tempfile) {

         }
          session->replyJsonArray( {tempfile.at(0),tempfile.at(1),tempfile.at(2),tempfile.at(3)} );
        }
        else
        {
            QStringList tempfile = getFileListUnderDir("/home/david/qtproject/filetest/test/download/B");
            QJsonArray tempArray;
            foreach (QString filename, tempfile) {
               tempArray.append(filename);
            }
            session->replyJsonArray(tempArray);

        }
    }
    else//
    {
        if(tempurlpath.contains("A"))
        {
         QStringList tempfile = getFileListUnderDir("/home/david/qtproject/filetest/test/download/A");

         foreach (QString filename, tempfile) {
             if(filename == tempbody)
              session->replyFile( "/home/david/qtproject/filetest/test/download/A/"+filename);
         }
        }

        else
        {
            QStringList tempfile = getFileListUnderDir("/home/david/qtproject/filetest/test/download/B");

            foreach (QString filename, tempfile) {
                if(filename == tempbody)
                  session->replyFile( "/home/david/qtproject/filetest/test/download/B/"+filename);
            }
        }

    }


//    session->replyImage( QImage( "/home/david/qtproject/filetest/test/process.png" ) );
//    session->replyBytes( QByteArray( 4,'\x24' ), "text" ); // $$$$

    qDebug() << "HTTP server listen: onHttpAccepted!" ;

    // 注1：因为一个session对应一个单一的HTTP请求，所以session只能reply一次
    // 注2：在reply后，session的生命周期不可控，所以reply后不要再调用session的接口了
}
