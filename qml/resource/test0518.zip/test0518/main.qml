import QtQuick 2.6
import QtQuick 2.2
import QtQuick.Window 2.2
import QtQuick.Controls 2.2 as Controls
import QtQuick.Controls 2.2
import QtQuick.Dialogs 1.2
import QtQuick.Layouts 1.3
import Qt.labs.platform 1.0
import QtQml.Models 2.1
import QtQuick.Controls.Styles 1.4
import QtQuick.Extras 1.4
import "content"


Window {
    id: pMyQml
    visible: true
    width: 666
    height: 666+40
    x:Screen.width / 2 - width / 2
    y:Screen.height / 2 - height / 2
    color: "#545454"
    title: qsTr("OTA工具")
    flags: Qt.FramelessWindowHint

    signal sendopensoursebutton1()
    signal sendopensoursebutton2()
    signal choosecomboxindex(int index)
    signal sendhttpfile()
    signal sendexit()

    MouseArea { //为窗口添加鼠标事件
                anchors.fill: parent
                acceptedButtons: Qt.LeftButton //只处理鼠标左键
                property point clickPos: "0,0"
                onPressed: { //接收鼠标按下事件
                    clickPos = Qt.point(mouse.x, mouse.y)
                }
                onPositionChanged: { //鼠标按下后改变位置
                    //鼠标偏移量
                    var delta = Qt.point(mouse.x-clickPos.x, mouse.y-clickPos.y)

                    pMyQml.setX(pMyQml.x+delta.x)
                    pMyQml.setY(pMyQml.y+delta.y)

                }
            }


    Button
    {
        id:opensoursebutton1
        objectName: "opensoursebutton1"

        x: 582
        y: 411
        width: 50
        height: 50
        background: Rectangle {
               color: "#545454"
           }
        Image {
            id: image1
            width: 50
            height: 50
            scale: quitMouse1.pressed ? 0.8 : 1.0
            source: "../icon/icon_ky50w3u6zb/wenjianjiawenjian.png"
            MouseArea {
                id: quitMouse1
                anchors.fill: parent
                anchors.margins: -10
                onClicked: {
                    //console.log("onClicked")
                    pMyQml.sendopensoursebutton1()

                }
            }
        }

        // tobuttondata()
    }
    Button
    {
        id:opensoursebutton2
        objectName: "opensoursebutton2"
        x: 574
        y: 475-15
        width: 50
        height: 50
        highlighted: true
         background: Rectangle {
                color: "#545454"
            }

        Image {
            width: 70
            height: 70
            scale: quitMouse2.pressed ? 0.8 : 1.0
            source: "../icon/icon_ky50w3u6zb/chuansong.png"//:/icon/icon_ky50w3u6zb/chuansong.png
            MouseArea {
                id: quitMouse2
                anchors.fill: parent
                anchors.margins: -10
                onClicked: {
                    pMyQml.sendhttpfile()
                    //console.log("onClicked")
                    //pMyQml.sendopensoursebutton2()
                    //helloid.updatedata()
                }
            }


        }
    }



        function getDialvalue(gvalue)
        {
            speedometer.getvalue=gvalue

           // console.log("dial.getvalue:",dial.getvalue)
        }

//        Dial {
//            id: dial
//            property var getvalue: 1
//            //anchors.top: parent.top-100
//            x: 211
//            y: 136
//            //anchors.centerIn: parent
//            value: getvalue//slider.x * 100 / (container.width - 32)

//        }

        Title
        {
               id: titleid
               x: -30
               y: 20
               width: 319
               height: 40
                //anchors.right: parent.right
                anchors.top: parent.top
                //anchors.centerIn: parent
        }

        Hello {
            id: helloid
            property var deviceidvalue:"rsu0001"
            property var typevalue:"rsu"
            property var sversionvalue:"v1.0.0"
            property var fversionvalue:"无文件"
            property var statevalue:"离线"

            anchors.right: parent.right
            anchors.bottom: parent.bottom
            deviceid:deviceidvalue
            type : typevalue
            sversion:sversionvalue
            fversion:fversionvalue
            state : statevalue
            //anchors.centerIn: parent
        }

          //新仪表盘，自绘
        CircularGauge {
            id: speedometer
            property var getvalue: 0
            value: getvalue
            //anchors.verticalCenter: parent.verticalCenter
            //anchors.centerIn: parent
            maximumValue: 101
            //property var getvalue: 1
            //anchors.top: parent.top-100
            x: 215
            y: 120
            //anchors.centerIn: parent
            //value: getvalue//slider.x * 100 / (container.width - 32)
            width: height
            height: 200

            style: DashboardGaugeStyle {}
        }
        function onsettabledata(id,type,sver,state)
        {
            helloid.deviceidvalue = id
            helloid.typevalue = type
            helloid.sversionvalue = sver
            helloid.statevalue = state
        }

        QuitButton {
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
        }


        Comboxtype{
            listModel: fruitModel
            x: 292
            y: 475
            width: 210
            height: 45

        }
        ListModel {
            id: fruitModel

            ListElement {
                name: "差分包"
//                    attributes: [
//                        ListElement { description: "Core" },
//                        ListElement { description: "Deciduous" }
//                    ]
            }
            ListElement {name: "V2X执行文件包"}
            ListElement { name: "v2x文件包"}
            ListElement {name: "config文件包"}
        }

        Rectangle {
            id: container
            property int oldWidth: 0
            anchors { bottom: parent.bottom; left: parent.left
                right: parent.right; leftMargin: 20; rightMargin: 20
                bottomMargin: 10
            }
            height: 16

            radius: 8
            opacity: 0.7
            antialiasing: true
            gradient: Gradient {
                GradientStop { position: 0.0; color: "gray" }
                GradientStop { position: 1.0; color: "white" }
            }

            onWidthChanged: {

                if (oldWidth === 0) {

                    oldWidth = width;
                    return
                }

                var desiredPercent = slider.x * 100 / (oldWidth - 32)
                slider.x = desiredPercent * (width - 32) / 100
                oldWidth = width
//                console.log("oldWidth",oldWidth)
//                console.log("desiredPercent",desiredPercent)
//                console.log("slider.x",slider.x)
            }
        }

        Text {
            id: element
            x: 10
            y: 423
            width: 87
            height: 61
            color: "#0d0c0c"
            text: qsTr("升级文件:")
            font.pixelSize: 20
        }
        Text {
            id: textEdit1
            x: 110
            y: 423
            width: 334
            height: 58
            color: "#0d0c0c"
            text: "无文件"
            font.pixelSize: 20
            wrapMode: Text.WordWrap //换行
        }
        Text {
            id: logtext
            x: 129
            y: 320
            width: 641
            height: 18
            text: qsTr("请先选择升级文件，等待设备上线...")
            horizontalAlignment: Text.AlignHCenter
            transformOrigin: Item.Center
            anchors.horizontalCenterOffset: -9
            anchors.horizontalCenter: parent.horizontalCenter
            font.pixelSize: 12
            wrapMode: Text.WordWrap //换行
        }
        Text {
            id: element3
            x: 10
            y: 482
            width: 140
            height: 35
            text: qsTr("升级类型:")
            font.pixelSize: 20
        }
        //程序最后执行:连接Qml信号与C++槽
            Component.onCompleted: {
                ctrl.tosettextEdit2.connect(pMyQml.onsettextEdit2)
                ctrl.tosettextEdit1.connect(pMyQml.onsettextEdit1)
                mqtt.tosendDialvalue.connect(pMyQml.getDialvalue)
                mqtt.tosetlogtext.connect(pMyQml.onsetlogtext)
                mqtt.tosettabledata.connect(pMyQml.onsettabledata)
                pMyQml.sendopensoursebutton1.connect(ctrl.opensoursebutton1)
                pMyQml.sendopensoursebutton2.connect(mqtt.opensoursebutton2)
                pMyQml.choosecomboxindex.connect(mqtt.oncomboxindex)
                pMyQml.sendhttpfile.connect(mqtt.gethttpfile)
                pMyQml.sendexit.connect(mqtt.exit)
            }

        function onsettextEdit1(str,str1,vision)//path,file,vision
        {

            textEdit1.text=str1
            //logtext.text="";
            onsetlogtext("\n成功打开:"+str)

            helloid.fversionvalue = vision
            helloid.updatedata()
            console.log("set slots textEdit1 : ",str)
        }

        function onsetlogtext(text)
        {
            if(logtext.text.length > 240 || logtext.text.split("\n").length>=6)
            {
                console.log("onsetlogtext : ",logtext.text.length)
                console.log("onsetlogtextsplit(\n) : ",logtext.text.split("\n").length)
                var temptext = logtext.text
                logtext.text = "";

            }


            logtext.text+=text
             helloid.updatedata()



        }

        function sendcomboxmessage(index)
        {
            choosecomboxindex(index)
        }

        function closewin()
        {
            sendexit()
        }

        function onsettextEdit2(str)
        {

         //   textEdit2.text=str

         //   console.log("set slots textEdit2 : ",str)

        }

}
