#include "control.h"
#include "qdebug.h"
#include "QFileDialog"
#include <QThread>
#include "QCoreApplication"
#include "QTime"
#include "QMessageBox"
control::control(QWidget *parent) : QWidget(parent)
{
qDebug()<<__FUNCTION__<<"control";

}
void control::uimessage()
{
    QMessageBox::information(NULL, "Title", "Content", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
}
void control::opensoursebutton1()
{
    QString filename,vision;
    qDebug()<<__FUNCTION__<<":opensoursebutton1 ok!";
    QString srcDirPath = QFileDialog::getOpenFileName(this,
                                                        tr("文件对话框"),
                                                        QCoreApplication::applicationDirPath()+"/updatefile",
                                                        tr("压缩文件(*.tar.bz2);;"
                                                           "图片文件(*png *jpg)"));

     if (srcDirPath.isEmpty())
     {
         return;
     }
     else
     {
         qDebug() << "srcDirPath=" << srcDirPath;
         filename = srcDirPath.split("/").last();
         vision = filename.split("_").at(3);
         emit tosettextEdit1(srcDirPath,filename,vision);
     }

     testfunction(1);
}
void control::opensoursebutton2()
{

}


void control::oncomboxindex(int index)
{
    qDebug() << "oncomboxindex=" << index;
}

void control::testfunction(uint state)
{
    qDebug()<<__FUNCTION__<<"state"<<state;
    if(state == 0)
    {
        for(int i = 1 ; i < 100 ; i++)
        {
            //emit tosendDialvalue(i);

        }
        Sleep(200);
    }
    else
    {
        for(int i = 1 ; i < 100 ; i++)
        {
            //emit tosendDialvalue(100-i);

        }
        Sleep(200);
    }

}

void control::Sleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void control::setName(QString name) noexcept
{
    //m_name= qMove(name);
    //emit qmlCall();

    //emit tosettextEdit2(name);

    //emit signalname();
}
QString control::getName() const noexcept
{
    return m_name;
}
void control::setAge(quint32 age) noexcept
{
    m_age = age;
    //emit signalage();
}
quint32 control::getAge() const noexcept
{
    return m_age;
}
void control::setDate(QDate date) noexcept
{
    m_date = date;
    //emit signaldate();
}
QDate control::getDate() const noexcept
{
    return m_date;
}

