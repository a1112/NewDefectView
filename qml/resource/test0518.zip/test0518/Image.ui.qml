mport QtQuick 2.6

Image {
    id: image
    width: 100
    height: 100
    source: "../test/icon/icon_ky50w3u6zb/a-feijihangban.png"
}
